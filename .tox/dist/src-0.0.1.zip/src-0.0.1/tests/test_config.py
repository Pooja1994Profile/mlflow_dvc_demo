# All the test cases function should start with test_function_name

def test_generic():
    a = 2
    b = 2
    assert a == b